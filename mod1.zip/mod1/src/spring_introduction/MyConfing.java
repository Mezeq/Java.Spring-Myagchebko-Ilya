package spring_introduction;
//Java-Code(1)
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("spring_introduction")
public class MyConfig {
}
