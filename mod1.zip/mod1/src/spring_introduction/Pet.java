package spring_introduction;

public interface Pet {
    public void say();
    }
