package spring_introduction;

public class Cat implements Pet {
    public void say() {
        System.out.println("Meow-Meow");
    }
}
